<!DOCTYPE html PUBLIC "-//W3c//DTD XHTML 1.0 Transitional//EN" " http://www.w3.org/TR/xhtml11/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    </head>
    
    <body>
        
        <form method="POST" action="action_page.php">
            
            Docent:<br>
                <input type="text" name="Docent">
                <br>
                
            Datum:<br>
                <input type="text" name="Datum">
                <br>
                   
            Aantekeningen:<br>
                <input type="text" name="Aantekeningen">
                <br>
                       
            <p>
                <input type="submit" value="Inloggen" />
            </p>
        </form>
    </body>
</html>