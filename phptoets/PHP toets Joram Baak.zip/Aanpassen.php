<?php
$sql = "SELECT * FROM schoolbezoek WHERE id=".$_POST['id'];
 echo 'Tot hier en niet verder';
 echo ("<br>");
 echo ("<br>");
echo " <tr> <td><a href='Form.php'>Hier log je uit</a></td>";
?>